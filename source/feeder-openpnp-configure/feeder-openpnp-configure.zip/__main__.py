import openpnp_feeders

openpnp_feeders.main()